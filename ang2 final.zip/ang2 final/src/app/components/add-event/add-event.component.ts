import { Component, OnInit } from '@angular/core';
import { EventInfo } from "../../models/event-info";
import { EventDataService } from "../../services/event-data.service";

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.css']
})
export class AddEventComponent implements OnInit {
 
  private eventInfo:EventInfo;
  constructor(private eventDataSvc:EventDataService) {
    this.eventInfo = new EventInfo();
    //this.eventInfo.title = "xyz";
   }

  ngOnInit() {
  }
  public save(form) :void{
    //alert("test");
    console.log(this.eventInfo);
    this.eventDataSvc.addEvent(this.eventInfo)
    .subscribe(
      data=>alert("Success"),
      err=>alert("Error")
    )
  }
}

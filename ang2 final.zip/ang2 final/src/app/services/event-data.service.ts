import { Injectable } from '@angular/core';
import { EventInfo } from "../models/event-info";
import { Http, Headers, RequestOptions } from "@angular/http/";
import { Observable } from "rxjs/Observable";
import 'rxjs/Rx';

@Injectable()
export class EventDataService {

  private events: EventInfo[];
  private readonly BASE_URL = "http://event-management.azurewebsites.net/api"
  constructor(private http: Http) {

  }

  public getEvents(): Observable<EventInfo[]> {  /// http module Observable asynchronous call or can use promise also
    let headerList = new Headers({ 'Accept': 'application/json' });
    let options = new RequestOptions({
      headers: headerList
    });

    return this.http.get(`${this.BASE_URL}/events`) //or u can use `${this.BASE_URL}/events` no need to use +
      .map(resp => {
        console.log(resp.json())
        return resp.json();
      }) //success call back 
      .catch(ex => Observable.throw(ex)); //failure call back
  }

  public addEvent(eventInfo:EventInfo):Observable<any>{
    let headerList = new Headers({"Content-Type": "application/json"});
    let options = new RequestOptions({
      headers:headerList
    });

    return this.http.post(`${this.BASE_URL}/events`,eventInfo,options)
    .map(res=>res.json())
    .catch(err=>Observable.throw(err))
  }

  public getEventById(id:number): Observable<EventInfo> {  /// http module Observable asynchronous call or can use promise also
    let headerList = new Headers({ 'Accept': 'application/json' });
    let options = new RequestOptions({
      headers: headerList
    });

    return this.http.get(`${this.BASE_URL}/events/${id}`) //or u can use `${this.BASE_URL}/events` no need to use +
      .map(resp => {
        console.log(resp.json())
        return resp.json();
      }) //success call back 
      .catch(ex => Observable.throw(ex)); //failure call back
  }

  public updateEvent(eventInfo:EventInfo):Observable<any>{
    let headerList = new Headers({"Content-Type": "application/json"});
    let options = new RequestOptions({
      headers:headerList
    });

    return this.http.put(`${this.BASE_URL}/events/${eventInfo.id}`,eventInfo,options)
    .map(res=>res.json())
    .catch(err=>Observable.throw(err))
  }

}

 //public getEvents() : EventInfo[]{
  //return this.events;
  //}
  //static data
  //this.events = [
  //new EventInfo("Advanced angular 2","Sara",new Date("2017/9/9"),"10 AM","01:PM","Chennai",4500,3000), 
  //new EventInfo("React JS","Prabha",new Date("2017/9/19"),"11 AM","01:PM","Pune",5000,3400),
  // new EventInfo("SharePoint","Karan",new Date("2017/9/29"),"10:30 AM","01:PM","Delhi", 2000, 2000), 
  // ];
